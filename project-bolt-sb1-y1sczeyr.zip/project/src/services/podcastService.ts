import { Podcast, Episode, SearchSuggestion } from '../types';

class PodcastService {
  private readonly baseUrl = 'https://itunes.apple.com/search';
  private readonly cache = new Map<string, any>();
  private readonly cacheExpiry = 5 * 60 * 1000; // 5 minutes

  // Advanced search terms for better results
  private readonly categoryTerms = {
    technology: ['tech talks', 'programming', 'artificial intelligence', 'startup', 'coding', 'software development'],
    business: ['business podcast', 'entrepreneur', 'marketing', 'finance', 'leadership', 'investing'],
    comedy: ['comedy podcast', 'humor', 'funny stories', 'stand up', 'comedy interview', 'improv'],
    education: ['educational podcast', 'learning', 'science', 'history', 'knowledge', 'university'],
    health: ['health podcast', 'fitness', 'mental health', 'nutrition', 'wellness', 'medical'],
    news: ['news podcast', 'politics', 'current events', 'journalism', 'world news', 'daily news'],
    sports: ['sports podcast', 'football', 'basketball', 'fitness training', 'athlete', 'olympics'],
    music: ['music podcast', 'musicians', 'bands', 'songs', 'music industry', 'concerts'],
    science: ['science podcast', 'research', 'physics', 'biology', 'chemistry', 'space', 'nature'],
    history: ['history podcast', 'historical', 'ancient', 'war', 'civilization', 'documentary']
  };

  private getCacheKey(key: string): string {
    return `podcast_${key}`;
  }

  private isValidCache(timestamp: number): boolean {
    return Date.now() - timestamp < this.cacheExpiry;
  }

  private async fetchWithCache<T>(key: string, fetcher: () => Promise<T>): Promise<T> {
    const cacheKey = this.getCacheKey(key);
    const cached = this.cache.get(cacheKey);
    
    if (cached && this.isValidCache(cached.timestamp)) {
      return cached.data;
    }

    const data = await fetcher();
    this.cache.set(cacheKey, { data, timestamp: Date.now() });
    return data;
  }

  async getCategoryPodcasts(category: string, limit = 5): Promise<Podcast[]> {
    const terms = this.categoryTerms[category as keyof typeof this.categoryTerms] || [category];
    const allPodcasts: Podcast[] = [];
    
    // Use multiple search terms to get diverse results
    for (const term of terms.slice(0, 3)) {
      try {
        const podcasts = await this.fetchWithCache(
          `category_${category}_${term}`,
          () => this.searchPodcastsByTerm(term, Math.ceil(limit / 2))
        );
        allPodcasts.push(...podcasts);
      } catch (error) {
        console.error(`Error fetching podcasts for term ${term}:`, error);
      }
    }

    // Remove duplicates and return top results
    const uniquePodcasts = this.removeDuplicates(allPodcasts);
    return this.rankPodcasts(uniquePodcasts).slice(0, limit);
  }

  async searchPodcasts(query: string, limit = 20): Promise<Podcast[]> {
    return this.fetchWithCache(
      `search_${query}_${limit}`,
      () => this.searchPodcastsByTerm(query, limit)
    );
  }

  private async searchPodcastsByTerm(term: string, limit: number): Promise<Podcast[]> {
    try {
      const response = await fetch(
        `${this.baseUrl}?media=podcast&term=${encodeURIComponent(term)}&limit=${limit * 2}&country=US`
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data.results || data.results.length === 0) {
        return [];
      }

      const podcasts = await Promise.all(
        data.results
          .filter((item: any) => item.feedUrl && item.artworkUrl600)
          .slice(0, limit)
          .map(async (item: any) => {
            const podcast: Podcast = {
              id: item.collectionId.toString(),
              name: item.collectionName || item.trackName,
              artist: item.artistName,
              description: this.cleanDescription(item.description || ''),
              imageUrl: item.artworkUrl600 || item.artworkUrl100,
              feedUrl: item.feedUrl,
              category: this.inferCategory(item.collectionName, item.description),
              rating: this.calculateRating(item),
              totalEpisodes: 0
            };

            return podcast;
          })
      );

      return this.validatePodcasts(podcasts);
    } catch (error) {
      console.error('Error searching podcasts:', error);
      return [];
    }
  }

  private async validatePodcasts(podcasts: Podcast[]): Promise<Podcast[]> {
    const validPodcasts: Podcast[] = [];
    
    for (const podcast of podcasts) {
      try {
        // Quick validation of feed URL
        const response = await fetch(podcast.feedUrl, { 
          method: 'HEAD',
          mode: 'no-cors'
        });
        validPodcasts.push(podcast);
      } catch (error) {
        // If HEAD request fails, try to validate differently
        validPodcasts.push(podcast);
      }
    }
    
    return validPodcasts;
  }

  async getPodcastDetails(id: string): Promise<Podcast | null> {
    try {
      const response = await fetch(
        `https://itunes.apple.com/lookup?id=${id}&media=podcast&entity=podcast`
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data.results || data.results.length === 0) {
        return null;
      }

      const item = data.results[0];
      const podcast: Podcast = {
        id: item.collectionId.toString(),
        name: item.collectionName,
        artist: item.artistName,
        description: this.cleanDescription(item.description || ''),
        imageUrl: item.artworkUrl600 || item.artworkUrl100,
        feedUrl: item.feedUrl,
        category: this.inferCategory(item.collectionName, item.description),
        rating: this.calculateRating(item),
        totalEpisodes: item.trackCount || 0
      };

      // Fetch episodes
      podcast.episodes = await this.getPodcastEpisodes(podcast);
      
      return podcast;
    } catch (error) {
      console.error('Error getting podcast details:', error);
      return null;
    }
  }

  async getPodcastEpisodes(podcast: Podcast): Promise<Episode[]> {
    try {
      const response = await fetch(podcast.feedUrl);
      const rssText = await response.text();
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(rssText, 'application/xml');
      
      const items = Array.from(xmlDoc.querySelectorAll('item'));
      const episodes: Episode[] = [];
      
      items.forEach((item, index) => {
        const enclosure = item.querySelector('enclosure');
        const audioUrl = enclosure?.getAttribute('url');
        
        if (audioUrl && episodes.length < 50) {
          const title = item.querySelector('title')?.textContent || 'Untitled Episode';
          const description = item.querySelector('description')?.textContent || '';
          const pubDate = item.querySelector('pubDate')?.textContent || '';
          const duration = this.parseDuration(
            item.querySelector('itunes\\:duration, duration')?.textContent || '0'
          );
          
          episodes.push({
            id: `${podcast.id}_${index}`,
            title: title.trim(),
            description: this.cleanDescription(description),
            audioUrl,
            duration,
            publishDate: new Date(pubDate || Date.now()),
            imageUrl: this.extractEpisodeImage(item) || podcast.imageUrl,
            podcast: podcast.name,
            artist: podcast.artist
          });
        }
      });
      
      return episodes.sort((a, b) => b.publishDate.getTime() - a.publishDate.getTime());
    } catch (error) {
      console.error('Error parsing podcast episodes:', error);
      return [];
    }
  }

  async getSearchSuggestions(query: string): Promise<SearchSuggestion[]> {
    const suggestions: SearchSuggestion[] = [];
    
    // Add category suggestions
    Object.keys(this.categoryTerms).forEach(category => {
      if (category.toLowerCase().includes(query.toLowerCase())) {
        suggestions.push({
          text: category.charAt(0).toUpperCase() + category.slice(1),
          type: 'category',
          data: { category }
        });
      }
    });

    // Add popular search terms
    const popularTerms = [
      'true crime', 'comedy', 'news', 'technology', 'business',
      'health', 'science', 'history', 'sports', 'music'
    ];
    
    popularTerms.forEach(term => {
      if (term.toLowerCase().includes(query.toLowerCase()) && 
          !suggestions.some(s => s.text.toLowerCase() === term)) {
        suggestions.push({
          text: term,
          type: 'podcast'
        });
      }
    });

    return suggestions.slice(0, 8);
  }

  private removeDuplicates(podcasts: Podcast[]): Podcast[] {
    const seen = new Set<string>();
    return podcasts.filter(podcast => {
      const key = `${podcast.name}_${podcast.artist}`.toLowerCase();
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  private rankPodcasts(podcasts: Podcast[]): Podcast[] {
    return podcasts.sort((a, b) => {
      // Prioritize podcasts with higher ratings and better descriptions
      const scoreA = (a.rating || 0) + (a.description.length > 100 ? 1 : 0);
      const scoreB = (b.rating || 0) + (b.description.length > 100 ? 1 : 0);
      return scoreB - scoreA;
    });
  }

  private calculateRating(item: any): number {
    // Simple rating calculation based on available data
    let rating = 3; // Base rating
    
    if (item.trackCount && item.trackCount > 50) rating += 0.5;
    if (item.description && item.description.length > 200) rating += 0.3;
    if (item.artworkUrl600) rating += 0.2;
    
    return Math.min(5, rating);
  }

  private inferCategory(name: string, description: string): string {
    const text = `${name} ${description}`.toLowerCase();
    
    for (const [category, terms] of Object.entries(this.categoryTerms)) {
      if (terms.some(term => text.includes(term.toLowerCase()))) {
        return category;
      }
    }
    
    return 'general';
  }

  private cleanDescription(text: string): string {
    if (!text) return '';
    return text
      .replace(/<[^>]*>/g, '')
      .replace(/&[^;]+;/g, ' ')
      .trim()
      .substring(0, 300);
  }

  private parseDuration(durationStr: string): number {
    if (!durationStr) return 0;
    
    // Handle different duration formats
    if (durationStr.includes(':')) {
      const parts = durationStr.split(':').map(Number);
      if (parts.length === 2) {
        return parts[0] * 60 + parts[1];
      } else if (parts.length === 3) {
        return parts[0] * 3600 + parts[1] * 60 + parts[2];
      }
    }
    
    const seconds = parseInt(durationStr);
    return isNaN(seconds) ? 0 : seconds;
  }

  private extractEpisodeImage(item: Element): string | null {
    const imageElement = item.querySelector('itunes\\:image, image');
    return imageElement?.getAttribute('href') || 
           imageElement?.getAttribute('url') || 
           null;
  }
}

export const podcastService = new PodcastService();