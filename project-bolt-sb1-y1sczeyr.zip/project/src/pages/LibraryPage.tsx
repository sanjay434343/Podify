import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Download, Clock, Bookmark } from 'lucide-react';

const LibraryPage: React.FC = () => {
  return (
    <motion.div
      className="page"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="page-header">
        <h1 className="page-title">Your Library</h1>
        <p className="page-subtitle">Your saved podcasts and episodes</p>
      </div>

      <div className="library-sections">
        <motion.section
          className="library-section"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="library-section-header">
            <Heart className="section-icon" size={24} />
            <h2>Liked Podcasts</h2>
          </div>
          <div className="empty-state">
            <p>You haven't liked any podcasts yet.</p>
            <p className="empty-state-subtitle">
              Start exploring and like podcasts to see them here.
            </p>
          </div>
        </motion.section>

        <motion.section
          className="library-section"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="library-section-header">
            <Download className="section-icon" size={24} />
            <h2>Downloaded Episodes</h2>
          </div>
          <div className="empty-state">
            <p>No downloaded episodes.</p>
            <p className="empty-state-subtitle">
              Download episodes to listen offline.
            </p>
          </div>
        </motion.section>

        <motion.section
          className="library-section"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="library-section-header">
            <Bookmark className="section-icon" size={24} />
            <h2>Saved Episodes</h2>
          </div>
          <div className="empty-state">
            <p>No saved episodes.</p>
            <p className="empty-state-subtitle">
              Save episodes to listen to later.
            </p>
          </div>
        </motion.section>
      </div>
    </motion.div>
  );
};

export default LibraryPage;