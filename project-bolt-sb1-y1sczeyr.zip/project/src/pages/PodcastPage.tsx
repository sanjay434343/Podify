import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Play, Heart, Share, MoreHorizontal, Clock } from 'lucide-react';
import { usePodcast } from '../contexts/PodcastContext';
import { usePlayer } from '../contexts/PlayerContext';
import { useHistory } from '../contexts/HistoryContext';
import { Podcast } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';

const PodcastPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getPodcastDetails } = usePodcast();
  const { playEpisode } = usePlayer();
  const { addToHistory } = useHistory();
  
  const [podcast, setPodcast] = useState<Podcast | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadPodcast(id);
    }
  }, [id]);

  const loadPodcast = async (podcastId: string) => {
    setLoading(true);
    try {
      const podcastData = await getPodcastDetails(podcastId);
      setPodcast(podcastData);
    } catch (error) {
      console.error('Error loading podcast:', error);
    }
    setLoading(false);
  };

  const handlePlayEpisode = (episodeIndex: number) => {
    if (!podcast?.episodes) return;
    
    const episode = podcast.episodes[episodeIndex];
    playEpisode(episode, podcast.episodes);
    addToHistory(episode, podcast);
  };

  const formatDuration = (seconds: number): string => {
    if (!seconds) return '';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  if (loading) {
    return <LoadingSpinner message="Loading podcast details..." />;
  }

  if (!podcast) {
    return (
      <div className="page">
        <div className="error-state">
          <h2>Podcast not found</h2>
          <p>The podcast you're looking for doesn't exist or couldn't be loaded.</p>
          <button onClick={() => navigate(-1)} className="btn-primary">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      className="page podcast-page"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <motion.div 
        className="podcast-header"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <button onClick={() => navigate(-1)} className="back-btn">
          <ArrowLeft size={24} />
        </button>

        <div className="podcast-hero">
          <div className="podcast-image-container">
            <img
              src={podcast.imageUrl}
              alt={podcast.name}
              className="podcast-image"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQwIiBoZWlnaHQ9IjI0MCIgdmlld0JveD0iMCAwIDI0MCAyNDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjI0MCIgaGVpZ2h0PSIyNDAiIGZpbGw9InZhcigtLWNhcmQtYmcpIi8+PHRleHQgeD0iMTIwIiB5PSIxMjAiIGZpbGw9InZhcigtLXRleHQtbXV0ZWQpIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iIGZvbnQtc2l6ZT0iNDAiPvCfjonwn46nPC90ZXh0Pjwvc3ZnPg==';
              }}
            />
          </div>

          <div className="podcast-info">
            <span className="podcast-type">PODCAST</span>
            <h1 className="podcast-title">{podcast.name}</h1>
            <p className="podcast-artist">{podcast.artist}</p>
            <div className="podcast-meta">
              <span>{podcast.episodes?.length || 0} episodes</span>
              {podcast.rating && (
                <>
                  <span>•</span>
                  <span>⭐ {podcast.rating.toFixed(1)}</span>
                </>
              )}
            </div>
            <p className="podcast-description">{podcast.description}</p>
          </div>
        </div>
      </motion.div>

      {/* Controls */}
      <motion.div 
        className="podcast-controls"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <button 
          className="play-all-btn"
          onClick={() => handlePlayEpisode(0)}
          disabled={!podcast.episodes?.length}
        >
          <Play size={20} />
          Play
        </button>

        <div className="podcast-actions">
          <button className="action-btn">
            <Heart size={20} />
          </button>
          <button className="action-btn">
            <Share size={20} />
          </button>
          <button className="action-btn">
            <MoreHorizontal size={20} />
          </button>
        </div>
      </motion.div>

      {/* Episodes */}
      <motion.div
        className="episodes-section"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <div className="episodes-header">
          <h2>Episodes</h2>
          <span className="episodes-count">
            {podcast.episodes?.length || 0} episodes
          </span>
        </div>

        <div className="episodes-list">
          {podcast.episodes?.map((episode, index) => (
            <motion.div
              key={episode.id}
              className="episode-item"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              onClick={() => handlePlayEpisode(index)}
            >
              <div className="episode-number">
                {index + 1}
              </div>

              <div className="episode-image">
                <img
                  src={episode.imageUrl}
                  alt={episode.title}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = podcast.imageUrl;
                  }}
                />
                <div className="episode-play-overlay">
                  <Play size={16} />
                </div>
              </div>

              <div className="episode-info">
                <h3 className="episode-title">{episode.title}</h3>
                <p className="episode-description">{episode.description}</p>
                <div className="episode-meta">
                  <span className="episode-date">
                    {formatDate(episode.publishDate)}
                  </span>
                  {episode.duration > 0 && (
                    <>
                      <span>•</span>
                      <span className="episode-duration">
                        <Clock size={12} />
                        {formatDuration(episode.duration)}
                      </span>
                    </>
                  )}
                </div>
              </div>

              <button className="episode-play-btn">
                <Play size={16} />
              </button>
            </motion.div>
          ))}
        </div>

        {(!podcast.episodes || podcast.episodes.length === 0) && (
          <div className="no-episodes">
            <p>No episodes available for this podcast.</p>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default PodcastPage;