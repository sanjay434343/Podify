import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, TrendingUp, Clock } from 'lucide-react';
import { usePodcast } from '../contexts/PodcastContext';
import { useHistory } from '../contexts/HistoryContext';
import PodcastGrid from '../components/PodcastGrid';
import LoadingSpinner from '../components/LoadingSpinner';
import { CATEGORIES } from '../types';

const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  const { 
    searchResults, 
    searchSuggestions, 
    loading, 
    searchPodcasts, 
    getSearchSuggestions,
    loadCategoryPodcasts,
    podcasts
  } = usePodcast();

  const categoryParam = searchParams.get('category');

  useEffect(() => {
    const saved = localStorage.getItem('searchHistory');
    if (saved) {
      setSearchHistory(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    if (categoryParam) {
      loadCategoryPodcasts(categoryParam);
    }
  }, [categoryParam]);

  const debouncedSearch = useCallback(
    debounce((searchQuery: string) => {
      if (searchQuery.trim()) {
        searchPodcasts(searchQuery);
        addToSearchHistory(searchQuery);
      }
    }, 500),
    []
  );

  const debouncedSuggestions = useCallback(
    debounce((searchQuery: string) => {
      if (searchQuery.trim()) {
        getSearchSuggestions(searchQuery);
      }
    }, 300),
    []
  );

  useEffect(() => {
    if (query) {
      debouncedSearch(query);
      debouncedSuggestions(query);
      setSearchParams({ q: query });
    } else {
      setSearchParams({});
    }
  }, [query]);

  const addToSearchHistory = (searchQuery: string) => {
    const newHistory = [searchQuery, ...searchHistory.filter(h => h !== searchQuery)].slice(0, 10);
    setSearchHistory(newHistory);
    localStorage.setItem('searchHistory', JSON.stringify(newHistory));
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion);
    setShowSuggestions(false);
  };

  const clearSearchHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem('searchHistory');
  };

  const currentCategory = CATEGORIES.find(cat => cat.id === categoryParam);
  const categoryPodcasts = categoryParam ? podcasts[categoryParam] || [] : [];

  return (
    <motion.div
      className="page"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="search-header">
        <div className="search-container">
          <div className="search-input-wrapper">
            <Search className="search-icon" size={20} />
            <input
              type="text"
              placeholder="What do you want to listen to?"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              className="search-input"
            />
          </div>

          <AnimatePresence>
            {showSuggestions && (query || searchHistory.length > 0) && (
              <motion.div
                className="search-suggestions"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                {query && searchSuggestions.length > 0 && (
                  <div className="suggestions-section">
                    <h4 className="suggestions-title">
                      <TrendingUp size={16} />
                      Suggestions
                    </h4>
                    {searchSuggestions.map((suggestion, index) => (
                      <button
                        key={index}
                        className="suggestion-item"
                        onClick={() => handleSuggestionClick(suggestion.text)}
                      >
                        <span className="suggestion-text">{suggestion.text}</span>
                        <span className="suggestion-type">{suggestion.type}</span>
                      </button>
                    ))}
                  </div>
                )}

                {!query && searchHistory.length > 0 && (
                  <div className="suggestions-section">
                    <div className="suggestions-header">
                      <h4 className="suggestions-title">
                        <Clock size={16} />
                        Recent searches
                      </h4>
                      <button onClick={clearSearchHistory} className="clear-history-btn">
                        Clear
                      </button>
                    </div>
                    {searchHistory.map((historyItem, index) => (
                      <button
                        key={index}
                        className="suggestion-item"
                        onClick={() => handleSuggestionClick(historyItem)}
                      >
                        <span className="suggestion-text">{historyItem}</span>
                      </button>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="search-content">
        {loading && (
          <LoadingSpinner message="Searching for podcasts..." />
        )}

        {/* Category Results */}
        {currentCategory && !query && (
          <motion.section
            className="section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="section-header">
              <h2 className="section-title">
                <span className="category-icon">{currentCategory.icon}</span>
                {currentCategory.name}
              </h2>
            </div>
            {categoryPodcasts.length > 0 ? (
              <PodcastGrid podcasts={categoryPodcasts} />
            ) : (
              <LoadingSpinner size="small" />
            )}
          </motion.section>
        )}

        {/* Search Results */}
        {query && !loading && (
          <motion.section
            className="section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="section-header">
              <h2 className="section-title">
                {searchResults.length > 0 
                  ? `Results for "${query}"` 
                  : `No results for "${query}"`
                }
              </h2>
              {searchResults.length > 0 && (
                <span className="results-count">
                  {searchResults.length} podcast{searchResults.length !== 1 ? 's' : ''}
                </span>
              )}
            </div>
            {searchResults.length > 0 ? (
              <PodcastGrid podcasts={searchResults} />
            ) : query && !loading ? (
              <div className="no-results">
                <p>Try searching for something else or browse our categories.</p>
              </div>
            ) : null}
          </motion.section>
        )}

        {/* Browse Categories */}
        {!query && !currentCategory && (
          <motion.section
            className="section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="section-header">
              <h2 className="section-title">Browse all</h2>
            </div>
            <div className="categories-browse-grid">
              {CATEGORIES.map((category, index) => (
                <motion.button
                  key={category.id}
                  className="category-browse-item"
                  style={{ '--category-color': category.color } as React.CSSProperties}
                  onClick={() => setSearchParams({ category: category.id })}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="category-browse-icon">{category.icon}</span>
                  <span className="category-browse-name">{category.name}</span>
                </motion.button>
              ))}
            </div>
          </motion.section>
        )}
      </div>
    </motion.div>
  );
};

// Debounce utility function
function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export default SearchPage;