import React from 'react';
import { motion } from 'framer-motion';
import { 
  Sun, 
  Moon, 
  Volume2, 
  Download, 
  Wifi, 
  Smartphone,
  Bell,
  Shield,
  HelpCircle,
  Info
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const SettingsPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  const settingSections = [
    {
      title: 'Appearance',
      settings: [
        {
          icon: theme === 'dark' ? Moon : Sun,
          label: 'Theme',
          description: 'Choose your preferred theme',
          action: (
            <button onClick={toggleTheme} className="theme-toggle-btn">
              {theme === 'dark' ? 'Dark' : 'Light'}
            </button>
          )
        }
      ]
    },
    {
      title: 'Playback',
      settings: [
        {
          icon: Volume2,
          label: 'Audio Quality',
          description: 'Choose audio quality for streaming',
          action: (
            <select className="setting-select">
              <option>High (320kbps)</option>
              <option>Normal (160kbps)</option>
              <option>Low (96kbps)</option>
            </select>
          )
        },
        {
          icon: Download,
          label: 'Download Quality',
          description: 'Choose audio quality for downloads',
          action: (
            <select className="setting-select">
              <option>High (320kbps)</option>
              <option>Normal (160kbps)</option>
            </select>
          )
        }
      ]
    },
    {
      title: 'Data & Storage',
      settings: [
        {
          icon: Wifi,
          label: 'Stream over WiFi only',
          description: 'Use cellular data for streaming',
          action: (
            <label className="toggle-switch">
              <input type="checkbox" />
              <span className="toggle-slider"></span>
            </label>
          )
        },
        {
          icon: Smartphone,
          label: 'Auto-download episodes',
          description: 'Automatically download new episodes',
          action: (
            <label className="toggle-switch">
              <input type="checkbox" />
              <span className="toggle-slider"></span>
            </label>
          )
        }
      ]
    },
    {
      title: 'Notifications',
      settings: [
        {
          icon: Bell,
          label: 'New episode notifications',
          description: 'Get notified about new episodes',
          action: (
            <label className="toggle-switch">
              <input type="checkbox" defaultChecked />
              <span className="toggle-slider"></span>
            </label>
          )
        }
      ]
    },
    {
      title: 'Privacy & Security',
      settings: [
        {
          icon: Shield,
          label: 'Privacy Settings',
          description: 'Manage your privacy preferences',
          action: <span className="setting-arrow">→</span>
        }
      ]
    },
    {
      title: 'Support',
      settings: [
        {
          icon: HelpCircle,
          label: 'Help & Support',
          description: 'Get help and contact support',
          action: <span className="setting-arrow">→</span>
        },
        {
          icon: Info,
          label: 'About Podify',
          description: 'Version 1.0.0',
          action: <span className="setting-arrow">→</span>
        }
      ]
    }
  ];

  return (
    <motion.div
      className="page"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="page-header">
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">Customize your Podify experience</p>
      </div>

      <div className="settings-content">
        {settingSections.map((section, sectionIndex) => (
          <motion.div
            key={section.title}
            className="settings-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: sectionIndex * 0.1 }}
          >
            <h2 className="settings-section-title">{section.title}</h2>
            <div className="settings-list">
              {section.settings.map((setting, settingIndex) => {
                const Icon = setting.icon;
                return (
                  <motion.div
                    key={setting.label}
                    className="setting-item"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ 
                      duration: 0.4, 
                      delay: (sectionIndex * 0.1) + (settingIndex * 0.05) 
                    }}
                  >
                    <div className="setting-info">
                      <Icon className="setting-icon" size={20} />
                      <div className="setting-text">
                        <h3 className="setting-label">{setting.label}</h3>
                        <p className="setting-description">{setting.description}</p>
                      </div>
                    </div>
                    <div className="setting-action">
                      {setting.action}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default SettingsPage;