import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Trash2, Play } from 'lucide-react';
import { useHistory } from '../contexts/HistoryContext';
import { usePlayer } from '../contexts/PlayerContext';

const HistoryPage: React.FC = () => {
  const { history, clearHistory } = useHistory();
  const { playEpisode } = usePlayer();

  const formatDate = (date: Date): string => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return 'Yesterday';
    
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: now.getFullYear() !== date.getFullYear() ? 'numeric' : undefined
    }).format(date);
  };

  const handlePlayEpisode = (historyItem: any) => {
    playEpisode(historyItem.episode);
  };

  return (
    <motion.div
      className="page"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="page-header">
        <div className="page-header-content">
          <div>
            <h1 className="page-title">Listening History</h1>
            <p className="page-subtitle">Your recently played episodes</p>
          </div>
          {history.length > 0 && (
            <button onClick={clearHistory} className="clear-history-btn">
              <Trash2 size={16} />
              Clear History
            </button>
          )}
        </div>
      </div>

      {history.length === 0 ? (
        <motion.div
          className="empty-state-large"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Clock size={64} className="empty-state-icon" />
          <h2>No listening history</h2>
          <p>Start listening to podcasts to see your history here.</p>
        </motion.div>
      ) : (
        <motion.div
          className="history-list"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {history.map((item, index) => (
            <motion.div
              key={`${item.episode.id}_${item.playedAt.getTime()}`}
              className="history-item"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              onClick={() => handlePlayEpisode(item)}
            >
              <div className="history-item-image">
                <img
                  src={item.episode.imageUrl}
                  alt={item.episode.title}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIHZpZXdCb3g9IjAgMCA2NCA2NCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIGZpbGw9InZhcigtLWNhcmQtYmcpIi8+PHRleHQgeD0iMzIiIHk9IjMyIiBmaWxsPSJ2YXIoLS10ZXh0LW11dGVkKSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9IjAuM2VtIiBmb250LXNpemU9IjI0Ij7wn46nPC90ZXh0Pjwvc3ZnPg==';
                  }}
                />
                <div className="history-item-play-overlay">
                  <Play size={16} />
                </div>
              </div>

              <div className="history-item-info">
                <h3 className="history-item-title">{item.episode.title}</h3>
                <p className="history-item-podcast">{item.podcast.name}</p>
                <div className="history-item-meta">
                  <span className="history-item-date">
                    {formatDate(item.playedAt)}
                  </span>
                  {item.progress > 0 && (
                    <>
                      <span>•</span>
                      <span className="history-item-progress">
                        {Math.round(item.progress * 100)}% played
                      </span>
                    </>
                  )}
                </div>
              </div>

              <button className="history-item-play-btn">
                <Play size={16} />
              </button>
            </motion.div>
          ))}
        </motion.div>
      )}
    </motion.div>
  );
};

export default HistoryPage;