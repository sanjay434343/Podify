import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { usePodcast } from '../contexts/PodcastContext';
import { useHistory } from '../contexts/HistoryContext';
import PodcastGrid from '../components/PodcastGrid';
import LoadingSpinner from '../components/LoadingSpinner';

const HomePage: React.FC = () => {
  const { podcasts, loading, loadCategoryPodcasts } = usePodcast();
  const { recentlyPlayed, getRecommendations } = useHistory();

  const categories = ['technology', 'business', 'comedy', 'education', 'health'];

  useEffect(() => {
    // Load all categories on mount
    categories.forEach(category => {
      loadCategoryPodcasts(category);
    });
  }, []);

  const recommendations = getRecommendations();

  if (loading && Object.keys(podcasts).length === 0) {
    return <LoadingSpinner message="Loading amazing podcasts..." />;
  }

  return (
    <motion.div
      className="page"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="page-header">
        <h1 className="page-title">Good {getGreeting()}</h1>
        <p className="page-subtitle">Discover amazing podcasts tailored for you</p>
      </div>

      {/* Recently Played */}
      {recentlyPlayed.length > 0 && (
        <motion.section
          className="section"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <div className="section-header">
            <h2 className="section-title">Recently Played</h2>
          </div>
          <div className="recently-played-grid">
            {recentlyPlayed.slice(0, 6).map((item, index) => (
              <motion.div
                key={`${item.episode.id}_${item.playedAt.getTime()}`}
                className="recently-played-item"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
              >
                <img src={item.episode.imageUrl} alt={item.episode.title} />
                <div className="recently-played-info">
                  <h4>{item.episode.title}</h4>
                  <p>{item.podcast.name}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>
      )}

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <motion.section
          className="section"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="section-header">
            <h2 className="section-title">Recommended for You</h2>
          </div>
          <PodcastGrid podcasts={recommendations} />
        </motion.section>
      )}

      {/* Category Sections */}
      {categories.map((category, index) => (
        <motion.section
          key={category}
          className="section"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 * (index + 3) }}
        >
          <div className="section-header">
            <h2 className="section-title">
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </h2>
            <button className="show-all-btn">Show all</button>
          </div>
          {podcasts[category] ? (
            <PodcastGrid podcasts={podcasts[category]} />
          ) : (
            <div className="section-loading">
              <LoadingSpinner size="small" />
            </div>
          )}
        </motion.section>
      ))}
    </motion.div>
  );
};

const getGreeting = (): string => {
  const hour = new Date().getHours();
  if (hour < 12) return 'morning';
  if (hour < 18) return 'afternoon';
  return 'evening';
};

export default HomePage;