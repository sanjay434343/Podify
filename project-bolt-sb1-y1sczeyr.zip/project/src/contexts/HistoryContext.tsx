import React, { createContext, useContext, useState, useEffect } from 'react';
import { Episode, Podcast } from '../types';

interface HistoryItem {
  episode: Episode;
  podcast: Podcast;
  playedAt: Date;
  progress: number;
}

interface HistoryContextType {
  history: HistoryItem[];
  recentlyPlayed: HistoryItem[];
  addToHistory: (episode: Episode, podcast: Podcast, progress?: number) => void;
  clearHistory: () => void;
  getRecommendations: () => Podcast[];
}

const HistoryContext = createContext<HistoryContextType | undefined>(undefined);

export const useHistory = () => {
  const context = useContext(HistoryContext);
  if (!context) {
    throw new Error('useHistory must be used within a HistoryProvider');
  }
  return context;
};

export const HistoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    const savedHistory = localStorage.getItem('podcastHistory');
    if (savedHistory) {
      try {
        const parsed = JSON.parse(savedHistory);
        setHistory(parsed.map((item: any) => ({
          ...item,
          playedAt: new Date(item.playedAt)
        })));
      } catch (error) {
        console.error('Error loading history:', error);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('podcastHistory', JSON.stringify(history));
  }, [history]);

  const addToHistory = (episode: Episode, podcast: Podcast, progress = 0) => {
    const historyItem: HistoryItem = {
      episode,
      podcast,
      playedAt: new Date(),
      progress
    };

    setHistory(prev => {
      // Remove existing entry for this episode
      const filtered = prev.filter(item => item.episode.id !== episode.id);
      // Add new entry at the beginning
      return [historyItem, ...filtered].slice(0, 100); // Keep only last 100 items
    });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('podcastHistory');
  };

  const recentlyPlayed = history.slice(0, 10);

  const getRecommendations = (): Podcast[] => {
    // Simple recommendation algorithm based on listening history
    const podcastCounts = new Map<string, { podcast: Podcast; count: number }>();
    
    history.forEach(item => {
      const key = item.podcast.id;
      if (podcastCounts.has(key)) {
        podcastCounts.get(key)!.count++;
      } else {
        podcastCounts.set(key, { podcast: item.podcast, count: 1 });
      }
    });

    return Array.from(podcastCounts.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)
      .map(item => item.podcast);
  };

  return (
    <HistoryContext.Provider value={{
      history,
      recentlyPlayed,
      addToHistory,
      clearHistory,
      getRecommendations
    }}>
      {children}
    </HistoryContext.Provider>
  );
};