import React, { createContext, useContext, useState } from 'react';
import { Podcast, Episode, SearchSuggestion } from '../types';
import { podcastService } from '../services/podcastService';

interface PodcastContextType {
  podcasts: { [category: string]: Podcast[] };
  searchResults: Podcast[];
  searchSuggestions: SearchSuggestion[];
  loading: boolean;
  loadCategoryPodcasts: (category: string) => Promise<void>;
  searchPodcasts: (query: string) => Promise<void>;
  getSearchSuggestions: (query: string) => Promise<void>;
  getPodcastDetails: (id: string) => Promise<Podcast | null>;
}

const PodcastContext = createContext<PodcastContextType | undefined>(undefined);

export const usePodcast = () => {
  const context = useContext(PodcastContext);
  if (!context) {
    throw new Error('usePodcast must be used within a PodcastProvider');
  }
  return context;
};

export const PodcastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [podcasts, setPodcasts] = useState<{ [category: string]: Podcast[] }>({});
  const [searchResults, setSearchResults] = useState<Podcast[]>([]);
  const [searchSuggestions, setSearchSuggestions] = useState<SearchSuggestion[]>([]);
  const [loading, setLoading] = useState(false);

  const loadCategoryPodcasts = async (category: string) => {
    if (podcasts[category]?.length > 0) return;
    
    setLoading(true);
    try {
      const categoryPodcasts = await podcastService.getCategoryPodcasts(category, 5);
      setPodcasts(prev => ({
        ...prev,
        [category]: categoryPodcasts
      }));
    } catch (error) {
      console.error(`Error loading ${category} podcasts:`, error);
    }
    setLoading(false);
  };

  const searchPodcasts = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setLoading(true);
    try {
      const results = await podcastService.searchPodcasts(query);
      setSearchResults(results);
    } catch (error) {
      console.error('Error searching podcasts:', error);
      setSearchResults([]);
    }
    setLoading(false);
  };

  const getSearchSuggestions = async (query: string) => {
    if (!query.trim()) {
      setSearchSuggestions([]);
      return;
    }

    try {
      const suggestions = await podcastService.getSearchSuggestions(query);
      setSearchSuggestions(suggestions);
    } catch (error) {
      console.error('Error getting suggestions:', error);
      setSearchSuggestions([]);
    }
  };

  const getPodcastDetails = async (id: string): Promise<Podcast | null> => {
    try {
      return await podcastService.getPodcastDetails(id);
    } catch (error) {
      console.error('Error getting podcast details:', error);
      return null;
    }
  };

  return (
    <PodcastContext.Provider value={{
      podcasts,
      searchResults,
      searchSuggestions,
      loading,
      loadCategoryPodcasts,
      searchPodcasts,
      getSearchSuggestions,
      getPodcastDetails
    }}>
      {children}
    </PodcastContext.Provider>
  );
};