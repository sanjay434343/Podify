import React, { createContext, useContext, useState, useRef, useEffect } from 'react';
import { Episode } from '../types';

interface PlayerState {
  currentEpisode: Episode | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isVisible: boolean;
  lyrics: string | null;
  isLoadingLyrics: boolean;
}

interface PlayerContextType {
  playerState: PlayerState;
  playEpisode: (episode: Episode) => void;
  togglePlay: () => void;
  seekTo: (time: number) => void;
  setVolume: (volume: number) => void;
  playNext: () => void;
  playPrevious: () => void;
  fetchLyrics: (episode: Episode) => Promise<void>;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export const usePlayer = () => {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
};

export const PlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playerState, setPlayerState] = useState<PlayerState>({
    currentEpisode: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 1,
    isVisible: false,
    lyrics: null,
    isLoadingLyrics: false
  });

  const [playlist, setPlaylist] = useState<Episode[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setPlayerState(prev => ({
        ...prev,
        currentTime: audio.currentTime,
        duration: audio.duration || 0
      }));
    };

    const handleEnded = () => {
      playNext();
    };

    const handleLoadedMetadata = () => {
      setPlayerState(prev => ({
        ...prev,
        duration: audio.duration || 0
      }));
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, []);

  const playEpisode = async (episode: Episode, episodeList?: Episode[]) => {
    const audio = audioRef.current;
    if (!audio) return;

    if (episodeList) {
      setPlaylist(episodeList);
      setCurrentIndex(episodeList.findIndex(e => e.id === episode.id));
    }

    setPlayerState(prev => ({
      ...prev,
      currentEpisode: episode,
      isVisible: true,
      lyrics: null
    }));

    audio.src = episode.audioUrl;
    audio.load();

    try {
      await audio.play();
      setPlayerState(prev => ({ ...prev, isPlaying: true }));
      await fetchLyrics(episode);
    } catch (error) {
      console.error('Error playing audio:', error);
    }
  };

  const togglePlay = async () => {
    const audio = audioRef.current;
    if (!audio || !playerState.currentEpisode) return;

    try {
      if (playerState.isPlaying) {
        audio.pause();
        setPlayerState(prev => ({ ...prev, isPlaying: false }));
      } else {
        await audio.play();
        setPlayerState(prev => ({ ...prev, isPlaying: true }));
      }
    } catch (error) {
      console.error('Error toggling play:', error);
    }
  };

  const seekTo = (time: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    
    audio.currentTime = time;
  };

  const setVolume = (volume: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    
    audio.volume = volume;
    setPlayerState(prev => ({ ...prev, volume }));
  };

  const playNext = () => {
    if (playlist.length === 0) return;
    
    const nextIndex = (currentIndex + 1) % playlist.length;
    setCurrentIndex(nextIndex);
    playEpisode(playlist[nextIndex]);
  };

  const playPrevious = () => {
    if (playlist.length === 0) return;
    
    const prevIndex = currentIndex === 0 ? playlist.length - 1 : currentIndex - 1;
    setCurrentIndex(prevIndex);
    playEpisode(playlist[prevIndex]);
  };

  const fetchLyrics = async (episode: Episode) => {
    setPlayerState(prev => ({ ...prev, isLoadingLyrics: true }));
    
    try {
      // Try multiple lyrics APIs
      const lyrics = await searchLyrics(episode.title, episode.artist);
      setPlayerState(prev => ({ 
        ...prev, 
        lyrics,
        isLoadingLyrics: false 
      }));
    } catch (error) {
      console.error('Error fetching lyrics:', error);
      setPlayerState(prev => ({ 
        ...prev, 
        lyrics: null,
        isLoadingLyrics: false 
      }));
    }
  };

  const searchLyrics = async (title: string, artist: string): Promise<string | null> => {
    // Clean up title and artist for better search results
    const cleanTitle = title.replace(/[^\w\s]/gi, '').trim();
    const cleanArtist = artist.replace(/[^\w\s]/gi, '').trim();
    
    try {
      // Try Lyrics.ovh API (free)
      const response = await fetch(
        `https://api.lyrics.ovh/v1/${encodeURIComponent(cleanArtist)}/${encodeURIComponent(cleanTitle)}`
      );
      
      if (response.ok) {
        const data = await response.json();
        return data.lyrics || null;
      }
    } catch (error) {
      console.error('Lyrics API error:', error);
    }
    
    return null;
  };

  return (
    <PlayerContext.Provider value={{
      playerState,
      playEpisode,
      togglePlay,
      seekTo,
      setVolume,
      playNext,
      playPrevious,
      fetchLyrics
    }}>
      {children}
      <audio ref={audioRef} preload="metadata" />
    </PlayerContext.Provider>
  );
};