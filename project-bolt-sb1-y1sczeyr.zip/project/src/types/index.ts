export interface Podcast {
  id: string;
  name: string;
  artist: string;
  description: string;
  imageUrl: string;
  feedUrl: string;
  category: string;
  episodes?: Episode[];
  rating?: number;
  totalEpisodes?: number;
}

export interface Episode {
  id: string;
  title: string;
  description: string;
  audioUrl: string;
  duration: number;
  publishDate: Date;
  imageUrl: string;
  podcast: string;
  artist: string;
  transcript?: string;
}

export interface SearchSuggestion {
  text: string;
  type: 'podcast' | 'episode' | 'category';
  data?: any;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export const CATEGORIES: Category[] = [
  { id: 'technology', name: 'Technology', icon: '💻', color: '#3B82F6' },
  { id: 'business', name: 'Business', icon: '💼', color: '#10B981' },
  { id: 'comedy', name: 'Comedy', icon: '😄', color: '#F59E0B' },
  { id: 'education', name: 'Education', icon: '🎓', color: '#8B5CF6' },
  { id: 'health', name: 'Health & Fitness', icon: '🏥', color: '#EF4444' },
  { id: 'news', name: 'News & Politics', icon: '📰', color: '#6B7280' },
  { id: 'sports', name: 'Sports', icon: '⚽', color: '#F97316' },
  { id: 'music', name: 'Music', icon: '🎵', color: '#EC4899' },
  { id: 'science', name: 'Science', icon: '🔬', color: '#06B6D4' },
  { id: 'history', name: 'History', icon: '📚', color: '#84CC16' }
];