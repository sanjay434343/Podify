import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Play } from 'lucide-react';
import { Podcast } from '../types';
import { usePlayer } from '../contexts/PlayerContext';

interface PodcastGridProps {
  podcasts: Podcast[];
}

const PodcastGrid: React.FC<PodcastGridProps> = ({ podcasts }) => {
  const navigate = useNavigate();
  const { playEpisode } = usePlayer();

  const handlePodcastClick = (podcast: Podcast) => {
    navigate(`/podcast/${podcast.id}`);
  };

  const handlePlayClick = async (e: React.MouseEvent, podcast: Podcast) => {
    e.stopPropagation();
    
    // If podcast has episodes, play the first one
    if (podcast.episodes && podcast.episodes.length > 0) {
      playEpisode(podcast.episodes[0], podcast.episodes);
    } else {
      // Navigate to podcast page to load episodes
      navigate(`/podcast/${podcast.id}`);
    }
  };

  return (
    <div className="podcast-grid">
      {podcasts.map((podcast, index) => (
        <motion.div
          key={podcast.id}
          className="podcast-card"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.05 }}
          whileHover={{ 
            scale: 1.05, 
            y: -8,
            transition: { duration: 0.2 }
          }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handlePodcastClick(podcast)}
        >
          <div className="podcast-card-image">
            <img
              src={podcast.imageUrl}
              alt={podcast.name}
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9InZhcigtLWNhcmQtYmcpIi8+PHRleHQgeD0iMTAwIiB5PSIxMDAiIGZpbGw9InZhcigtLXRleHQtbXV0ZWQpIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iIGZvbnQtc2l6ZT0iNDAiPvCfjonwn46nPC90ZXh0Pjwvc3ZnPg==';
              }}
            />
            <motion.button
              className="podcast-play-btn"
              onClick={(e) => handlePlayClick(e, podcast)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
            >
              <Play size={20} fill="currentColor" />
            </motion.button>
          </div>
          
          <div className="podcast-card-content">
            <h3 className="podcast-card-title">{podcast.name}</h3>
            <p className="podcast-card-artist">{podcast.artist}</p>
            {podcast.rating && (
              <div className="podcast-card-rating">
                ⭐ {podcast.rating.toFixed(1)}
              </div>
            )}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default PodcastGrid;