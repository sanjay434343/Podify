import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX,
  Shuffle,
  Repeat,
  Heart,
  Maximize2,
  FileText
} from 'lucide-react';
import { usePlayer } from '../contexts/PlayerContext';
import { useHistory } from '../contexts/HistoryContext';
import LyricsModal from './LyricsModal';

const PlayerBar: React.FC = () => {
  const { playerState, togglePlay, seekTo, setVolume, playNext, playPrevious } = usePlayer();
  const { addToHistory } = useHistory();
  const [showLyrics, setShowLyrics] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [previousVolume, setPreviousVolume] = useState(1);

  if (!playerState.isVisible || !playerState.currentEpisode) {
    return null;
  }

  const formatTime = (seconds: number): string => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const percentage = (e.clientX - rect.left) / rect.width;
    const newTime = percentage * playerState.duration;
    seekTo(newTime);
  };

  const handleVolumeChange = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const percentage = (e.clientX - rect.left) / rect.width;
    const newVolume = Math.max(0, Math.min(1, percentage));
    setVolume(newVolume);
    setIsMuted(newVolume === 0);
  };

  const toggleMute = () => {
    if (isMuted) {
      setVolume(previousVolume);
      setIsMuted(false);
    } else {
      setPreviousVolume(playerState.volume);
      setVolume(0);
      setIsMuted(true);
    }
  };

  const progressPercentage = playerState.duration 
    ? (playerState.currentTime / playerState.duration) * 100 
    : 0;

  return (
    <>
      <motion.div 
        className="player-bar"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Now Playing */}
        <div className="now-playing">
          <div className="now-playing-image">
            <img
              src={playerState.currentEpisode.imageUrl}
              alt={playerState.currentEpisode.title}
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTYiIGhlaWdodD0iNTYiIHZpZXdCb3g9IjAgMCA1NiA1NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNTYiIGhlaWdodD0iNTYiIGZpbGw9InZhcigtLWNhcmQtYmcpIi8+PHRleHQgeD0iMjgiIHk9IjI4IiBmaWxsPSJ2YXIoLS10ZXh0LW11dGVkKSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9IjAuM2VtIiBmb250LXNpemU9IjIwIj7wn46nPC90ZXh0Pjwvc3ZnPg==';
              }}
            />
          </div>
          
          <div className="now-playing-info">
            <h4 className="track-title">{playerState.currentEpisode.title}</h4>
            <p className="track-artist">{playerState.currentEpisode.artist}</p>
          </div>

          <div className="now-playing-actions">
            <motion.button
              className="action-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart size={16} />
            </motion.button>
          </div>
        </div>

        {/* Player Controls */}
        <div className="player-controls">
          <div className="control-buttons">
            <motion.button 
              className="control-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Shuffle size={16} />
            </motion.button>
            
            <motion.button 
              onClick={playPrevious}
              className="control-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <SkipBack size={20} />
            </motion.button>
            
            <motion.button
              onClick={togglePlay}
              className="play-pause-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {playerState.isPlaying ? <Pause size={20} /> : <Play size={20} />}
            </motion.button>
            
            <motion.button 
              onClick={playNext}
              className="control-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <SkipForward size={20} />
            </motion.button>
            
            <motion.button 
              className="control-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Repeat size={16} />
            </motion.button>
          </div>
          
          {/* Progress Bar */}
          <div className="progress-container">
            <span className="time-display">
              {formatTime(playerState.currentTime)}
            </span>
            
            <div 
              className="progress-bar"
              onClick={handleSeek}
            >
              <div 
                className="progress-fill"
                style={{ width: `${progressPercentage}%` }}
              />
              <div 
                className="progress-handle"
                style={{ left: `${progressPercentage}%` }}
              />
            </div>
            
            <span className="time-display">
              {formatTime(playerState.duration)}
            </span>
          </div>
        </div>

        {/* Volume and Additional Controls */}
        <div className="additional-controls">
          <motion.button
            onClick={() => setShowLyrics(true)}
            className="control-btn"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            disabled={!playerState.lyrics && !playerState.isLoadingLyrics}
          >
            <FileText size={16} />
          </motion.button>

          <motion.button
            className="control-btn"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Maximize2 size={16} />
          </motion.button>

          <div className="volume-controls">
            <motion.button
              onClick={toggleMute}
              className="control-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isMuted || playerState.volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </motion.button>
            
            <div 
              className="volume-bar"
              onClick={handleVolumeChange}
            >
              <div 
                className="volume-fill"
                style={{ width: `${playerState.volume * 100}%` }}
              />
            </div>
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {showLyrics && (
          <LyricsModal
            episode={playerState.currentEpisode}
            lyrics={playerState.lyrics}
            isLoading={playerState.isLoadingLyrics}
            onClose={() => setShowLyrics(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default PlayerBar;