import React from 'react';
import { motion } from 'framer-motion';
import { X, Loader } from 'lucide-react';
import { Episode } from '../types';

interface LyricsModalProps {
  episode: Episode;
  lyrics: string | null;
  isLoading: boolean;
  onClose: () => void;
}

const LyricsModal: React.FC<LyricsModalProps> = ({ episode, lyrics, isLoading, onClose }) => {
  return (
    <motion.div
      className="lyrics-modal-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="lyrics-modal"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="lyrics-header">
          <div className="lyrics-info">
            <h3>{episode.title}</h3>
            <p>{episode.artist}</p>
          </div>
          <button onClick={onClose} className="close-btn">
            <X size={24} />
          </button>
        </div>

        <div className="lyrics-content">
          {isLoading ? (
            <div className="lyrics-loading">
              <Loader className="spinner" size={32} />
              <p>Searching for lyrics...</p>
            </div>
          ) : lyrics ? (
            <div className="lyrics-text">
              {lyrics.split('\n').map((line, index) => (
                <p key={index} className="lyrics-line">
                  {line || '\u00A0'}
                </p>
              ))}
            </div>
          ) : (
            <div className="no-lyrics">
              <p>No lyrics available for this episode.</p>
              <p className="no-lyrics-subtitle">
                Lyrics are typically available for music podcasts and some audio content.
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default LyricsModal;