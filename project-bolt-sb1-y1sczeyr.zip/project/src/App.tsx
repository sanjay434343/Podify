import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './components/Sidebar';
import PlayerBar from './components/PlayerBar';
import HomePage from './pages/HomePage';
import SearchPage from './pages/SearchPage';
import PodcastPage from './pages/PodcastPage';
import LibraryPage from './pages/LibraryPage';
import HistoryPage from './pages/HistoryPage';
import SettingsPage from './pages/SettingsPage';
import { ThemeProvider } from './contexts/ThemeContext';
import { PlayerProvider } from './contexts/PlayerContext';
import { PodcastProvider } from './contexts/PodcastContext';
import { HistoryProvider } from './contexts/HistoryContext';
import './App.css';

function App() {
  return (
    <ThemeProvider>
      <PodcastProvider>
        <PlayerProvider>
          <HistoryProvider>
            <Router>
              <AppContent />
            </Router>
          </HistoryProvider>
        </PlayerProvider>
      </PodcastProvider>
    </ThemeProvider>
  );
}

function AppContent() {
  return (
    <div className="app">
      <Sidebar />
      <main className="main-content">
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/podcast/:id" element={<PodcastPage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </AnimatePresence>
      </main>
      <PlayerBar />
    </div>
  );
}

export default App;