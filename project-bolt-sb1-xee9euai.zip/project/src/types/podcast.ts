export interface Podcast {
  collectionId: string;
  collectionName: string;
  artistName: string;
  artworkUrl100: string;
  artworkUrl600: string;
  feedUrl: string;
  trackCount?: number;
  primaryGenreName?: string;
  episodes?: Episode[];
}

export interface Episode {
  title: string;
  description: string;
  audioUrl: string;
  pubDate: string;
  duration: string;
  image: string;
  podcast: string;
  artist: string;
  index?: number;
}

export interface CurrentTrack {
  title: string;
  artist: string;
  image: string;
  audioUrl: string;
  duration: number;
}

export interface PlayerState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  currentTrack: CurrentTrack | null;
}

export type ThemeMode = 'dark' | 'light' | 'custom';

export interface ThemeState {
  mode: ThemeMode;
  customColors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
  };
}