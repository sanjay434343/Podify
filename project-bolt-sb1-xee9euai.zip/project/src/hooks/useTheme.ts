import { useState, useEffect } from 'react';
import { ThemeMode, ThemeState } from '../types/podcast';

const defaultCustomColors = {
  primary: '#8B5CF6',
  secondary: '#06B6D4',
  accent: '#F59E0B',
  background: '#0F172A',
  surface: '#1E293B',
  text: '#F8FAFC',
};

export const useTheme = () => {
  const [themeState, setThemeState] = useState<ThemeState>(() => {
    const saved = localStorage.getItem('podify-theme');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return {
          mode: 'dark' as ThemeMode,
          customColors: defaultCustomColors,
        };
      }
    }
    return {
      mode: 'dark' as ThemeMode,
      customColors: defaultCustomColors,
    };
  });

  useEffect(() => {
    localStorage.setItem('podify-theme', JSON.stringify(themeState));
    applyTheme(themeState);
  }, [themeState]);

  const applyTheme = (theme: ThemeState) => {
    const root = document.documentElement;
    
    if (theme.mode === 'light') {
      root.classList.remove('dark', 'custom');
      root.classList.add('light');
    } else if (theme.mode === 'custom') {
      root.classList.remove('dark', 'light');
      root.classList.add('custom');
      
      // Apply custom colors as CSS variables
      root.style.setProperty('--color-primary', theme.customColors.primary);
      root.style.setProperty('--color-secondary', theme.customColors.secondary);
      root.style.setProperty('--color-accent', theme.customColors.accent);
      root.style.setProperty('--color-background', theme.customColors.background);
      root.style.setProperty('--color-surface', theme.customColors.surface);
      root.style.setProperty('--color-text', theme.customColors.text);
    } else {
      root.classList.remove('light', 'custom');
      root.classList.add('dark');
    }
  };

  const setThemeMode = (mode: ThemeMode) => {
    setThemeState(prev => ({ ...prev, mode }));
  };

  const updateCustomColor = (colorKey: keyof ThemeState['customColors'], value: string) => {
    setThemeState(prev => ({
      ...prev,
      customColors: {
        ...prev.customColors,
        [colorKey]: value,
      },
    }));
  };

  const resetCustomColors = () => {
    setThemeState(prev => ({
      ...prev,
      customColors: defaultCustomColors,
    }));
  };

  return {
    themeState,
    setThemeMode,
    updateCustomColor,
    resetCustomColors,
  };
};