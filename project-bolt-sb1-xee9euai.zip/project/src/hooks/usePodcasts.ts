import { useState, useEffect, useCallback } from 'react';
import { Podcast, Episode } from '../types/podcast';

const RANDOM_SEARCHES = [
  'technology podcast', 'business podcast', 'comedy podcast', 'education podcast',
  'health podcast', 'news podcast', 'sports podcast', 'music podcast',
  'science podcast', 'history podcast', 'true crime podcast', 'interview podcast',
  'startup podcast', 'marketing podcast', 'finance podcast', 'self improvement',
  'mindfulness podcast', 'cooking podcast', 'travel podcast', 'culture podcast'
];

const CATEGORIES = {
  featured: ['Joe Rogan', 'TED Talks', 'This American Life', 'Serial'],
  technology: ['tech', 'programming', 'AI', 'startup'],
  business: ['business', 'entrepreneur', 'marketing', 'finance'],
  comedy: ['comedy', 'humor', 'funny', 'stand up'],
  education: ['education', 'learning', 'science', 'history'],
  health: ['health', 'fitness', 'mental health', 'nutrition'],
  news: ['news', 'politics', 'current events', 'journalism'],
  sports: ['sports', 'football', 'basketball', 'fitness'],
  music: ['music', 'musicians', 'bands', 'songs']
};

export const usePodcasts = () => {
  const [podcasts, setPodcasts] = useState<Record<string, Podcast[]>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [selectedPodcast, setSelectedPodcast] = useState<Podcast | null>(null);
  const [randomSearchResults, setRandomSearchResults] = useState<Podcast[]>([]);
  const [currentRandomSearch, setCurrentRandomSearch] = useState<string>('');

  const fetchPodcasts = useCallback(async (category: string, limit = 6) => {
    if (loading[category]) return;

    setLoading(prev => ({ ...prev, [category]: true }));

    try {
      const terms = CATEGORIES[category as keyof typeof CATEGORIES] || [category];
      const randomTerm = terms[Math.floor(Math.random() * terms.length)];
      
      const response = await fetch(
        `https://itunes.apple.com/search?media=podcast&term=${encodeURIComponent(randomTerm)}&limit=${limit * 2}`
      );
      const data = await response.json();

      if (data.results && data.results.length > 0) {
        const validPodcasts = await filterValidPodcasts(data.results, limit);
        setPodcasts(prev => ({ ...prev, [category]: validPodcasts }));
      }
    } catch (error) {
      console.error(`Error fetching ${category} podcasts:`, error);
    } finally {
      setLoading(prev => ({ ...prev, [category]: false }));
    }
  }, [loading]);

  const filterValidPodcasts = async (podcastList: any[], limit: number): Promise<Podcast[]> => {
    const valid: Podcast[] = [];
    
    for (const podcast of podcastList) {
      if (valid.length >= limit) break;
      
      if (podcast.feedUrl) {
        try {
          const response = await fetch(podcast.feedUrl);
          if (response.ok) {
            valid.push({
              collectionId: podcast.collectionId.toString(),
              collectionName: podcast.collectionName,
              artistName: podcast.artistName,
              artworkUrl100: podcast.artworkUrl100,
              artworkUrl600: podcast.artworkUrl600,
              feedUrl: podcast.feedUrl,
              trackCount: podcast.trackCount,
              primaryGenreName: podcast.primaryGenreName,
            });
          }
        } catch (error) {
          continue;
        }
      }
    }
    
    return valid;
  };

  const fetchPodcastEpisodes = async (podcast: Podcast): Promise<Episode[]> => {
    try {
      const response = await fetch(podcast.feedUrl);
      const rssText = await response.text();
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(rssText, "application/xml");
      
      const items = Array.from(xmlDoc.querySelectorAll("item"));
      const episodes: Episode[] = [];
      
      for (const item of items) {
        const enclosure = item.querySelector("enclosure");
        const audioUrl = enclosure?.getAttribute("url");
        
        if (audioUrl) {
          const title = item.querySelector("title")?.textContent || 'Untitled Episode';
          const description = item.querySelector("description")?.textContent || '';
          const pubDate = item.querySelector("pubDate")?.textContent || '';
          const duration = item.querySelector("duration")?.textContent || 
                          item.querySelector("itunes\\:duration")?.textContent || '';
          
          const episodeImage = item.querySelector("image")?.getAttribute("href") ||
                               item.querySelector("itunes\\:image")?.getAttribute("href") ||
                               extractImageFromContent(description) ||
                               podcast.artworkUrl600 || podcast.artworkUrl100;
          
          episodes.push({
            title: title.trim(),
            description: cleanDescription(description),
            audioUrl,
            pubDate,
            duration,
            image: episodeImage,
            podcast: podcast.collectionName,
            artist: podcast.artistName
          });
        }
      }
      
      return episodes.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
    } catch (error) {
      console.error('Error fetching episodes:', error);
      return [];
    }
  };

  const searchPodcasts = async (query: string): Promise<Podcast[]> => {
    if (!query.trim()) return [];

    try {
      const response = await fetch(
        `https://itunes.apple.com/search?media=podcast&term=${encodeURIComponent(query)}&limit=20`
      );
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        return await filterValidPodcasts(data.results, 12);
      }
      return [];
    } catch (error) {
      console.error('Search error:', error);
      return [];
    }
  };

  const performRandomSearch = useCallback(async () => {
    const randomTerm = RANDOM_SEARCHES[Math.floor(Math.random() * RANDOM_SEARCHES.length)];
    setCurrentRandomSearch(randomTerm);
    
    try {
      const response = await fetch(
        `https://itunes.apple.com/search?media=podcast&term=${encodeURIComponent(randomTerm)}&limit=16`
      );
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        const validPodcasts = await filterValidPodcasts(data.results, 8);
        setRandomSearchResults(validPodcasts);
        return validPodcasts;
      }
      return [];
    } catch (error) {
      console.error('Random search error:', error);
      return [];
    }
  }, []);

  const cleanDescription = (text: string): string => {
    if (!text) return '';
    return text.replace(/<[^>]*>/g, '').trim().substring(0, 100) + '...';
  };

  const extractImageFromContent = (content: string): string | null => {
    if (!content) return null;
    const imgRegex = /<img[^>]+src=["']([^"']+)["'][^>]*>/i;
    const match = content.match(imgRegex);
    return match ? match[1] : null;
  };

  useEffect(() => {
    // Load initial featured content
    fetchPodcasts('featured');
    fetchPodcasts('technology');
    fetchPodcasts('business');
    fetchPodcasts('comedy');
    performRandomSearch();
  }, [fetchPodcasts]);

  return {
    podcasts,
    loading,
    selectedPodcast,
    setSelectedPodcast,
    fetchPodcasts,
    fetchPodcastEpisodes,
    searchPodcasts,
    randomSearchResults,
    currentRandomSearch,
    performRandomSearch,
  };
};