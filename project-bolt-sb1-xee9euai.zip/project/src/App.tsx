import React, { useState } from 'react';
import { Menu } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { SearchBar } from './components/SearchBar';
import { PodcastGrid } from './components/PodcastGrid';
import { PodcastDetail } from './components/PodcastDetail';
import { PlayerBar } from './components/PlayerBar';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ThemeSelector } from './components/ThemeSelector';
import { usePodcasts } from './hooks/usePodcasts';
import { useAudioPlayer } from './hooks/useAudioPlayer';
import { useTheme } from './hooks/useTheme';
import { Podcast, Episode } from './types/podcast';

type ViewMode = 'home' | 'search' | 'category' | 'detail';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [themeModalOpen, setThemeModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('home');
  const [searchResults, setSearchResults] = useState<Podcast[]>([]);
  const [currentCategory, setCurrentCategory] = useState<string>('');
  
  const { 
    podcasts, 
    loading, 
    selectedPodcast, 
    setSelectedPodcast, 
    fetchPodcasts,
    randomSearchResults,
    currentRandomSearch,
    performRandomSearch
  } = usePodcasts();
  
  const { 
    audioRef, 
    playerState, 
    playTrack, 
    togglePlay, 
    seekTo, 
    setVolume 
  } = useAudioPlayer();

  const { themeState } = useTheme();

  const handlePodcastPlay = async (podcast: Podcast) => {
    try {
      // You could fetch the first episode here or implement a preview functionality
      console.log('Playing podcast:', podcast.collectionName);
      // For now, just open the podcast detail
      setSelectedPodcast(podcast);
      setViewMode('detail');
    } catch (error) {
      console.error('Error playing podcast:', error);
    }
  };

  const handleEpisodePlay = async (episode: Episode) => {
    await playTrack({
      title: episode.title,
      artist: episode.artist,
      image: episode.image,
      audioUrl: episode.audioUrl,
      duration: 0, // Will be set when audio loads
    });
  };

  const handlePodcastSelect = (podcast: Podcast) => {
    setSelectedPodcast(podcast);
    setViewMode('detail');
  };

  const handleCategorySelect = async (category: string) => {
    setCurrentCategory(category);
    setViewMode('category');
    await fetchPodcasts(category, 12);
  };

  const handleSearchResults = (results: Podcast[]) => {
    setSearchResults(results);
    setViewMode('search');
  };

  const handleSearchClear = () => {
    setSearchResults([]);
    setViewMode('home');
  };

  const handleHomeClick = () => {
    setViewMode('home');
    setSelectedPodcast(null);
  };

  const handleSearchClick = () => {
    setViewMode('search');
  };

  const handleBackToHome = () => {
    // Prevent flickering by using a smooth transition
    const albumPage = document.getElementById('album-page');
    const homePage = document.getElementById('home-page');
    
    if (albumPage && homePage) {
      albumPage.style.opacity = '0';
      setTimeout(() => {
        setViewMode('home');
        setSelectedPodcast(null);
        albumPage.style.opacity = '1';
      }, 150);
    } else {
      setViewMode('home');
      setSelectedPodcast(null);
    }
  };

  const renderContent = () => {
    if (viewMode === 'detail' && selectedPodcast) {
      return (
        <div id="album-page" className="transition-opacity duration-300">
          <PodcastDetail
            podcast={selectedPodcast}
            onBack={handleBackToHome}
            onEpisodePlay={handleEpisodePlay}
          />
        </div>
      );
    }

    return (
      <div id="home-page" className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 dark:from-slate-900 dark:via-purple-900/20 dark:to-slate-900 light:from-white light:via-purple-50 light:to-gray-100 custom:from-[var(--color-background)] custom:via-[var(--color-primary)]/10 custom:to-[var(--color-background)] p-6 md:p-8 transition-colors duration-300">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 text-white dark:text-white light:text-gray-900 custom:text-[var(--color-text)] hover:bg-white/10 dark:hover:bg-white/10 light:hover:bg-gray-100 custom:hover:bg-[var(--color-primary)]/10 rounded-lg transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>
          
          <SearchBar onSearchResults={handleSearchResults} onClear={handleSearchClear} />
        </div>

        {/* Content */}
        <div className="max-w-screen-2xl mx-auto">
          {viewMode === 'search' && (
            <>
              {searchResults.length > 0 ? (
                <PodcastGrid
                  title="Search Results"
                  podcasts={searchResults}
                  onPodcastPlay={handlePodcastPlay}
                  onPodcastSelect={handlePodcastSelect}
                />
              ) : (
                <div className="text-center py-16">
                  <div className="text-6xl mb-4">🔍</div>
                  <h2 className="text-2xl font-bold text-white dark:text-white light:text-gray-900 custom:text-[var(--color-text)] mb-2">Search for podcasts</h2>
                  <p className="text-slate-400 dark:text-slate-400 light:text-gray-600 custom:text-[var(--color-text)]/70">Find your next favorite show</p>
                </div>
              )}
            </>
          )}

          {viewMode === 'category' && (
            <PodcastGrid
              title={currentCategory.charAt(0).toUpperCase() + currentCategory.slice(1)}
              podcasts={podcasts[currentCategory] || []}
              loading={loading[currentCategory]}
              onPodcastPlay={handlePodcastPlay}
              onPodcastSelect={handlePodcastSelect}
            />
          )}

          {viewMode === 'home' && (
            <>
              {/* Hero Section */}
              <div className="mb-12 text-center">
                <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 dark:from-purple-400 dark:via-pink-400 dark:to-purple-400 light:from-purple-600 light:via-pink-600 light:to-purple-600 custom:from-[var(--color-primary)] custom:via-[var(--color-secondary)] custom:to-[var(--color-primary)] bg-clip-text text-transparent mb-4">
                  Discover Amazing Podcasts
                </h1>
                <p className="text-xl text-slate-300 dark:text-slate-300 light:text-gray-600 custom:text-[var(--color-text)]/80 max-w-2xl mx-auto">
                  Explore thousands of podcasts from every genre and find your next obsession
                </p>
              </div>

              {/* Random Discovery Section */}
              <PodcastGrid
                title={`Discover: ${currentRandomSearch}`}
                podcasts={randomSearchResults}
                onPodcastPlay={handlePodcastPlay}
                onPodcastSelect={handlePodcastSelect}
                onShowAll={performRandomSearch}
              />

              {/* Featured Podcasts */}
              <PodcastGrid
                title="Featured"
                podcasts={podcasts.featured || []}
                loading={loading.featured}
                onPodcastPlay={handlePodcastPlay}
                onPodcastSelect={handlePodcastSelect}
              />

              {/* Technology */}
              <PodcastGrid
                title="Technology"
                podcasts={podcasts.technology || []}
                loading={loading.technology}
                onPodcastPlay={handlePodcastPlay}
                onPodcastSelect={handlePodcastSelect}
                onShowAll={() => handleCategorySelect('technology')}
              />

              {/* Business */}
              <PodcastGrid
                title="Business"
                podcasts={podcasts.business || []}
                loading={loading.business}
                onPodcastPlay={handlePodcastPlay}
                onPodcastSelect={handlePodcastSelect}
                onShowAll={() => handleCategorySelect('business')}
              />

              {/* Comedy */}
              <PodcastGrid
                title="Comedy"
                podcasts={podcasts.comedy || []}
                loading={loading.comedy}
                onPodcastPlay={handlePodcastPlay}
                onPodcastSelect={handlePodcastSelect}
                onShowAll={() => handleCategorySelect('comedy')}
              />
            </>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="flex min-h-screen bg-slate-900 dark:bg-slate-900 light:bg-white custom:bg-[var(--color-background)] transition-colors duration-300">
      {/* Hidden Audio Element */}
      <audio ref={audioRef} preload="metadata" />

      {/* Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        onCategorySelect={handleCategorySelect}
        onHomeClick={handleHomeClick}
        onSearchClick={handleSearchClick}
        onThemeClick={() => setThemeModalOpen(true)}
      />

      {/* Main Content */}
      <div className="flex-1 lg:ml-0">
        {renderContent()}
      </div>

      {/* Player Bar */}
      <PlayerBar
        playerState={playerState}
        onTogglePlay={togglePlay}
        onSeek={seekTo}
        onVolumeChange={setVolume}
      />

      {/* Theme Selector Modal */}
      <ThemeSelector
        isOpen={themeModalOpen}
        onClose={() => setThemeModalOpen(false)}
      />
    </div>
  );
}

export default App;