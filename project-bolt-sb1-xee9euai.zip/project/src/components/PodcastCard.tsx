import React from 'react';
import { Play } from 'lucide-react';
import { Podcast } from '../types/podcast';

interface PodcastCardProps {
  podcast: Podcast;
  onPlay: (podcast: Podcast) => void;
  onSelect: (podcast: Podcast) => void;
}

export const PodcastCard: React.FC<PodcastCardProps> = ({ podcast, onPlay, onSelect }) => {
  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onPlay(podcast);
  };

  return (
    <div 
      onClick={() => onSelect(podcast)}
      className="group bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-4 cursor-pointer transition-all duration-300 hover:transform hover:scale-105 hover:shadow-2xl hover:border-purple-500/50"
    >
      <div className="relative mb-4">
        <img 
          src={podcast.artworkUrl600 || podcast.artworkUrl100} 
          alt={podcast.collectionName}
          className="w-full aspect-square object-cover rounded-lg shadow-lg"
          onError={(e) => {
            e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiM0QjVTNjMiLz48dGV4dCB4PSIxMDAiIHk9IjEwMCIgZmlsbD0iIzlDQTNBRiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9IjAuM2VtIiBmb250LXNpemU9IjQwIj7wn46nPC90ZXh0Pjwvc3ZnPg==';
          }}
        />
        
        {/* Play Button Overlay */}
        <button
          onClick={handlePlayClick}
          className="absolute bottom-2 right-2 w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 hover:scale-110"
        >
          <Play className="w-5 h-5 text-white ml-0.5" fill="currentColor" />
        </button>
      </div>

      <div className="space-y-2">
        <h3 className="font-semibold text-white text-sm line-clamp-2 group-hover:text-purple-200 transition-colors">
          {podcast.collectionName}
        </h3>
        <p className="text-slate-400 text-xs line-clamp-2">
          {podcast.artistName}
        </p>
        {podcast.primaryGenreName && (
          <span className="inline-block px-2 py-1 bg-purple-500/20 text-purple-300 text-xs rounded-full">
            {podcast.primaryGenreName}
          </span>
        )}
      </div>
    </div>
  );
};