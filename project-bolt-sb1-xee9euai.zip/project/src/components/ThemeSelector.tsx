import React, { useState } from 'react';
import { Palette, Sun, Moon, Settings, X } from 'lucide-react';
import { useTheme } from '../hooks/useTheme';
import { ThemeMode } from '../types/podcast';

interface ThemeSelectorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ isOpen, onClose }) => {
  const { themeState, setThemeMode, updateCustomColor, resetCustomColors } = useTheme();
  const [activeTab, setActiveTab] = useState<'modes' | 'custom'>('modes');

  if (!isOpen) return null;

  const themeOptions: { mode: ThemeMode; icon: React.ReactNode; label: string; description: string }[] = [
    {
      mode: 'dark',
      icon: <Moon className="w-5 h-5" />,
      label: 'Dark Mode',
      description: 'Easy on the eyes in low light'
    },
    {
      mode: 'light',
      icon: <Sun className="w-5 h-5" />,
      label: 'Light Mode',
      description: 'Clean and bright interface'
    },
    {
      mode: 'custom',
      icon: <Palette className="w-5 h-5" />,
      label: 'Custom Theme',
      description: 'Create your own color scheme'
    }
  ];

  const colorInputs = [
    { key: 'primary' as const, label: 'Primary Color', description: 'Main brand color' },
    { key: 'secondary' as const, label: 'Secondary Color', description: 'Accent highlights' },
    { key: 'accent' as const, label: 'Accent Color', description: 'Interactive elements' },
    { key: 'background' as const, label: 'Background', description: 'Main background' },
    { key: 'surface' as const, label: 'Surface Color', description: 'Card backgrounds' },
    { key: 'text' as const, label: 'Text Color', description: 'Primary text' },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 light:bg-white custom:bg-[var(--color-surface)] rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-700 light:border-slate-200 custom:border-slate-600">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white light:text-slate-900 custom:text-[var(--color-text)]">
            Theme Settings
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 light:hover:bg-slate-100 custom:hover:bg-slate-600 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-slate-500 dark:text-slate-400 light:text-slate-500 custom:text-[var(--color-text)]" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-700 light:border-slate-200 custom:border-slate-600">
          <button
            onClick={() => setActiveTab('modes')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
              activeTab === 'modes'
                ? 'text-purple-600 dark:text-purple-400 light:text-purple-600 custom:text-[var(--color-primary)] border-b-2 border-purple-600 dark:border-purple-400 light:border-purple-600 custom:border-[var(--color-primary)]'
                : 'text-slate-600 dark:text-slate-400 light:text-slate-600 custom:text-[var(--color-text)] hover:text-slate-900 dark:hover:text-white light:hover:text-slate-900'
            }`}
          >
            Theme Modes
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
              activeTab === 'custom'
                ? 'text-purple-600 dark:text-purple-400 light:text-purple-600 custom:text-[var(--color-primary)] border-b-2 border-purple-600 dark:border-purple-400 light:border-purple-600 custom:border-[var(--color-primary)]'
                : 'text-slate-600 dark:text-slate-400 light:text-slate-600 custom:text-[var(--color-text)] hover:text-slate-900 dark:hover:text-white light:hover:text-slate-900'
            }`}
          >
            Custom Colors
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-96 overflow-y-auto">
          {activeTab === 'modes' && (
            <div className="space-y-3">
              {themeOptions.map((option) => (
                <button
                  key={option.mode}
                  onClick={() => setThemeMode(option.mode)}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all ${
                    themeState.mode === option.mode
                      ? 'bg-purple-100 dark:bg-purple-900/30 light:bg-purple-100 custom:bg-[var(--color-primary)]/20 border-2 border-purple-500 dark:border-purple-400 light:border-purple-500 custom:border-[var(--color-primary)]'
                      : 'bg-slate-50 dark:bg-slate-700 light:bg-slate-50 custom:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 light:hover:bg-slate-100 custom:hover:bg-slate-600 border-2 border-transparent'
                  }`}
                >
                  <div className={`p-2 rounded-lg ${
                    themeState.mode === option.mode
                      ? 'bg-purple-500 text-white'
                      : 'bg-slate-200 dark:bg-slate-600 light:bg-slate-200 custom:bg-slate-600 text-slate-600 dark:text-slate-300 light:text-slate-600 custom:text-[var(--color-text)]'
                  }`}>
                    {option.icon}
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className={`font-semibold ${
                      themeState.mode === option.mode
                        ? 'text-purple-900 dark:text-purple-100 light:text-purple-900 custom:text-[var(--color-primary)]'
                        : 'text-slate-900 dark:text-white light:text-slate-900 custom:text-[var(--color-text)]'
                    }`}>
                      {option.label}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 light:text-slate-600 custom:text-[var(--color-text)]/70">
                      {option.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {activeTab === 'custom' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-slate-900 dark:text-white light:text-slate-900 custom:text-[var(--color-text)]">
                  Custom Colors
                </h3>
                <button
                  onClick={resetCustomColors}
                  className="text-sm text-purple-600 dark:text-purple-400 light:text-purple-600 custom:text-[var(--color-primary)] hover:underline"
                >
                  Reset to Default
                </button>
              </div>
              
              {colorInputs.map((colorInput) => (
                <div key={colorInput.key} className="space-y-2">
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 light:text-slate-700 custom:text-[var(--color-text)]">
                    {colorInput.label}
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={themeState.customColors[colorInput.key]}
                      onChange={(e) => updateCustomColor(colorInput.key, e.target.value)}
                      className="w-12 h-10 rounded-lg border border-slate-300 dark:border-slate-600 light:border-slate-300 custom:border-slate-600 cursor-pointer"
                    />
                    <div className="flex-1">
                      <input
                        type="text"
                        value={themeState.customColors[colorInput.key]}
                        onChange={(e) => updateCustomColor(colorInput.key, e.target.value)}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-700 light:bg-white custom:bg-slate-700 border border-slate-300 dark:border-slate-600 light:border-slate-300 custom:border-slate-600 rounded-lg text-slate-900 dark:text-white light:text-slate-900 custom:text-[var(--color-text)] text-sm font-mono"
                        placeholder="#000000"
                      />
                      <p className="text-xs text-slate-500 dark:text-slate-400 light:text-slate-500 custom:text-[var(--color-text)]/60 mt-1">
                        {colorInput.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};