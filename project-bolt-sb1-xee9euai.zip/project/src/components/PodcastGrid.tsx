import React from 'react';
import { PodcastCard } from './PodcastCard';
import { Podcast } from '../types/podcast';

interface PodcastGridProps {
  title: string;
  podcasts: Podcast[];
  loading?: boolean;
  onPodcastPlay: (podcast: Podcast) => void;
  onPodcastSelect: (podcast: Podcast) => void;
  onShowAll?: () => void;
}

export const PodcastGrid: React.FC<PodcastGridProps> = ({
  title,
  podcasts,
  loading,
  onPodcastPlay,
  onPodcastSelect,
  onShowAll
}) => {
  if (loading) {
    return (
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">{title}</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="animate-pulse">
              <div className="bg-slate-700 aspect-square rounded-lg mb-4"></div>
              <div className="h-4 bg-slate-700 rounded mb-2"></div>
              <div className="h-3 bg-slate-700 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!podcasts.length) {
    return null;
  }

  return (
    <div className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
          {title}
        </h2>
        {onShowAll && (
          <button 
            onClick={onShowAll}
            className="text-slate-400 hover:text-white text-sm font-medium transition-colors"
          >
            Show all
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-4 gap-4 md:gap-6">
        {podcasts.map((podcast) => (
          <PodcastCard
            key={podcast.collectionId}
            podcast={podcast}
            onPlay={onPodcastPlay}
            onSelect={onPodcastSelect}
          />
        ))}
      </div>
    </div>
  );
};