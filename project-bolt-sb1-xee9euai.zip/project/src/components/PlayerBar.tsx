import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart } from 'lucide-react';
import { PlayerState } from '../types/podcast';

interface PlayerBarProps {
  playerState: PlayerState;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onVolumeChange: (volume: number) => void;
}

export const PlayerBar: React.FC<PlayerBarProps> = ({
  playerState,
  onTogglePlay,
  onSeek,
  onVolumeChange,
}) => {
  const formatTime = (seconds: number): string => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const newTime = percent * playerState.duration;
    onSeek(newTime);
  };

  const handleVolumeClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    onVolumeChange(Math.max(0, Math.min(1, percent)));
  };

  if (!playerState.currentTrack) {
    return null;
  }

  const progress = playerState.duration > 0 ? (playerState.currentTime / playerState.duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-slate-900 to-slate-800 backdrop-blur-xl border-t border-slate-700/50 px-4 py-3 z-50">
      <div className="flex items-center justify-between max-w-screen-2xl mx-auto">
        {/* Now Playing Info */}
        <div className="flex items-center gap-3 flex-1 min-w-0 max-w-xs">
          <img 
            src={playerState.currentTrack.image} 
            alt={playerState.currentTrack.title}
            className="w-12 h-12 rounded-lg object-cover shadow-lg"
          />
          <div className="min-w-0 flex-1">
            <h4 className="text-white text-sm font-medium truncate">
              {playerState.currentTrack.title}
            </h4>
            <p className="text-slate-400 text-xs truncate">
              {playerState.currentTrack.artist}
            </p>
          </div>
          <button className="text-slate-400 hover:text-white transition-colors hidden sm:block">
            <Heart className="w-4 h-4" />
          </button>
        </div>

        {/* Player Controls */}
        <div className="flex flex-col items-center flex-1 max-w-2xl mx-8">
          <div className="flex items-center gap-4 mb-2">
            <button className="text-slate-400 hover:text-white transition-colors hidden md:block">
              <SkipBack className="w-5 h-5" />
            </button>
            
            <button
              onClick={onTogglePlay}
              className="w-10 h-10 bg-white hover:bg-slate-200 rounded-full flex items-center justify-center transition-all duration-200 transform hover:scale-105"
            >
              {playerState.isPlaying ? (
                <Pause className="w-5 h-5 text-black" fill="currentColor" />
              ) : (
                <Play className="w-5 h-5 text-black ml-0.5" fill="currentColor" />
              )}
            </button>
            
            <button className="text-slate-400 hover:text-white transition-colors hidden md:block">
              <SkipForward className="w-5 h-5" />
            </button>
          </div>

          {/* Progress Bar */}
          <div className="flex items-center gap-2 w-full text-xs text-slate-400">
            <span className="w-10 text-right">{formatTime(playerState.currentTime)}</span>
            <div 
              className="flex-1 h-1 bg-slate-600 rounded-full cursor-pointer group"
              onClick={handleProgressClick}
            >
              <div 
                className="h-full bg-white rounded-full relative transition-all duration-100 group-hover:bg-purple-400"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <span className="w-10">{formatTime(playerState.duration)}</span>
          </div>
        </div>

        {/* Volume Control */}
        <div className="flex items-center gap-3 flex-1 justify-end max-w-xs">
          <Volume2 className="w-5 h-5 text-slate-400 hidden lg:block" />
          <div 
            className="w-20 h-1 bg-slate-600 rounded-full cursor-pointer group hidden lg:block"
            onClick={handleVolumeClick}
          >
            <div 
              className="h-full bg-white rounded-full relative transition-all duration-100 group-hover:bg-purple-400"
              style={{ width: `${playerState.volume * 100}%` }}
            >
              <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};