import React from 'react';
import { Home, Search, Library, Headphones, Briefcase, Laugh, BookOpen, Heart, Newspaper, Zap, Music, Settings } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  onCategorySelect: (category: string) => void;
  onHomeClick: () => void;
  onSearchClick: () => void;
  onThemeClick: () => void;
}

const navigationItems = [
  { icon: Home, label: 'Home', id: 'home' },
  { icon: Search, label: 'Search', id: 'search' },
  { icon: Library, label: 'Your Library', id: 'library' },
];

const categories = [
  { icon: Zap, label: 'Technology', id: 'technology' },
  { icon: Briefcase, label: 'Business', id: 'business' },
  { icon: Laugh, label: 'Comedy', id: 'comedy' },
  { icon: BookOpen, label: 'Education', id: 'education' },
  { icon: Heart, label: 'Health', id: 'health' },
  { icon: Newspaper, label: 'News', id: 'news' },
  { icon: Music, label: 'Music', id: 'music' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onToggle,
  onCategorySelect,
  onHomeClick,
  onSearchClick,
  onThemeClick,
}) => {
  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onToggle}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 h-full w-72 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 
        dark:from-slate-900 dark:via-slate-800 dark:to-slate-900
        light:from-white light:via-gray-50 light:to-gray-100
        custom:from-[var(--color-background)] custom:via-[var(--color-surface)] custom:to-[var(--color-background)]
        backdrop-blur-xl border-r border-slate-700/50 dark:border-slate-700/50 light:border-gray-200 custom:border-slate-600/50
        z-50 transition-transform duration-300 ease-in-out overflow-hidden
        lg:relative lg:translate-x-0 lg:w-80
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 h-full flex flex-col">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Headphones className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 dark:from-purple-400 dark:to-pink-400 light:from-purple-600 light:to-pink-600 custom:from-[var(--color-primary)] custom:to-[var(--color-secondary)] bg-clip-text text-transparent">
              Podify
            </h1>
          </div>

          {/* Navigation */}
          <nav className="space-y-2 mb-8 flex-shrink-0">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === 'home') onHomeClick();
                  if (item.id === 'search') onSearchClick();
                  if (window.innerWidth < 1024) onToggle();
                }}
                className="w-full flex items-center gap-4 px-4 py-3 text-slate-300 dark:text-slate-300 light:text-gray-600 custom:text-[var(--color-text)]/70 hover:text-white dark:hover:text-white light:hover:text-gray-900 custom:hover:text-[var(--color-text)] hover:bg-white/10 dark:hover:bg-white/10 light:hover:bg-gray-100 custom:hover:bg-[var(--color-primary)]/10 rounded-lg transition-all duration-200 group"
              >
                <item.icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Categories */}
          <div className="flex-1 overflow-y-auto">
            <h3 className="text-sm font-semibold text-slate-400 dark:text-slate-400 light:text-gray-500 custom:text-[var(--color-text)]/60 uppercase tracking-wider mb-4 px-4">
              Browse by Category
            </h3>
            <div className="space-y-1">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    onCategorySelect(category.id);
                    if (window.innerWidth < 1024) onToggle();
                  }}
                  className="w-full flex items-center gap-4 px-4 py-3 text-slate-300 dark:text-slate-300 light:text-gray-600 custom:text-[var(--color-text)]/70 hover:text-white dark:hover:text-white light:hover:text-gray-900 custom:hover:text-[var(--color-text)] hover:bg-white/10 dark:hover:bg-white/10 light:hover:bg-gray-100 custom:hover:bg-[var(--color-primary)]/10 rounded-lg transition-all duration-200 group"
                >
                  <category.icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">{category.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Theme Settings */}
          <div className="mt-auto pt-4 border-t border-slate-700/50 dark:border-slate-700/50 light:border-gray-200 custom:border-slate-600/50">
            <button
              onClick={() => {
                onThemeClick();
                if (window.innerWidth < 1024) onToggle();
              }}
              className="w-full flex items-center gap-4 px-4 py-3 text-slate-300 dark:text-slate-300 light:text-gray-600 custom:text-[var(--color-text)]/70 hover:text-white dark:hover:text-white light:hover:text-gray-900 custom:hover:text-[var(--color-text)] hover:bg-white/10 dark:hover:bg-white/10 light:hover:bg-gray-100 custom:hover:bg-[var(--color-primary)]/10 rounded-lg transition-all duration-200 group"
            >
              <Settings className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span className="font-medium">Theme Settings</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};