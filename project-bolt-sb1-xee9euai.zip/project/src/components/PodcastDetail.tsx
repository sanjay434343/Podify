import React, { useState, useEffect } from 'react';
import { ArrowLeft, Play, Clock, Calendar } from 'lucide-react';
import { Podcast, Episode } from '../types/podcast';
import { usePodcasts } from '../hooks/usePodcasts';

interface PodcastDetailProps {
  podcast: Podcast;
  onBack: () => void;
  onEpisodePlay: (episode: Episode) => void;
}

export const PodcastDetail: React.FC<PodcastDetailProps> = ({ 
  podcast, 
  onBack, 
  onEpisodePlay 
}) => {
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [loading, setLoading] = useState(true);
  const { fetchPodcastEpisodes } = usePodcasts();

  useEffect(() => {
    const loadEpisodes = async () => {
      setLoading(true);
      const podcastEpisodes = await fetchPodcastEpisodes(podcast);
      setEpisodes(podcastEpisodes);
      setLoading(false);
    };

    loadEpisodes();
  }, [podcast, fetchPodcastEpisodes]);

  const formatDuration = (duration: string): string => {
    if (!duration) return '';
    if (duration.includes(':')) return duration;
    
    const seconds = parseInt(duration);
    if (!isNaN(seconds)) {
      const minutes = Math.floor(seconds / 60);
      const remainingSeconds = seconds % 60;
      return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    return '';
  };

  const formatDate = (dateString: string): string => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 light:from-white light:via-gray-50 light:to-gray-100 custom:from-[var(--color-background)] custom:via-[var(--color-surface)] custom:to-[var(--color-background)] transition-colors duration-300">
      {/* Header */}
      <div className="bg-gradient-to-b from-purple-900/50 dark:from-purple-900/50 light:from-purple-100/50 custom:from-[var(--color-primary)]/20 to-transparent p-6 md:p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-300 dark:text-slate-300 light:text-gray-600 custom:text-[var(--color-text)]/70 hover:text-white dark:hover:text-white light:hover:text-gray-900 custom:hover:text-[var(--color-text)] mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        <div className="flex flex-col md:flex-row gap-6 md:gap-8">
          <div className="flex-shrink-0">
            <img 
              src={podcast.artworkUrl600 || podcast.artworkUrl100} 
              alt={podcast.collectionName}
              className="w-48 h-48 md:w-64 md:h-64 object-cover rounded-xl shadow-2xl mx-auto md:mx-0"
            />
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <p className="text-sm font-medium text-purple-300 dark:text-purple-300 light:text-purple-600 custom:text-[var(--color-primary)] uppercase tracking-wider mb-2">
              Podcast
            </p>
            <h1 className="text-3xl md:text-5xl font-bold text-white dark:text-white light:text-gray-900 custom:text-[var(--color-text)] mb-4 leading-tight">
              {podcast.collectionName}
            </h1>
            <p className="text-xl text-slate-300 dark:text-slate-300 light:text-gray-600 custom:text-[var(--color-text)]/80 mb-4">{podcast.artistName}</p>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-sm text-slate-400 dark:text-slate-400 light:text-gray-500 custom:text-[var(--color-text)]/60">
              {podcast.primaryGenreName && (
                <span className="px-3 py-1 bg-purple-500/20 dark:bg-purple-500/20 light:bg-purple-100 custom:bg-[var(--color-primary)]/20 text-purple-300 dark:text-purple-300 light:text-purple-600 custom:text-[var(--color-primary)] rounded-full">
                  {podcast.primaryGenreName}
                </span>
              )}
              <span>{episodes.length} episodes</span>
            </div>
          </div>
        </div>

        {/* Play Button */}
        <div className="flex justify-center md:justify-start mt-8">
          <button
            onClick={() => episodes.length > 0 && onEpisodePlay({ ...episodes[0], index: 0 })}
            className="flex items-center gap-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg"
            disabled={episodes.length === 0}
          >
            <Play className="w-5 h-5" fill="currentColor" />
            Play Latest Episode
          </button>
        </div>
      </div>

      {/* Episodes List */}
      <div className="p-6 md:p-8">
        <h2 className="text-2xl font-bold text-white dark:text-white light:text-gray-900 custom:text-[var(--color-text)] mb-6">Episodes</h2>
        
        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, index) => (
              <div key={index} className="animate-pulse bg-slate-800/50 dark:bg-slate-800/50 light:bg-gray-100 custom:bg-[var(--color-surface)]/50 rounded-lg p-4">
                <div className="h-5 bg-slate-700 dark:bg-slate-700 light:bg-gray-300 custom:bg-slate-600 rounded mb-2"></div>
                <div className="h-4 bg-slate-700 dark:bg-slate-700 light:bg-gray-300 custom:bg-slate-600 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-slate-700 dark:bg-slate-700 light:bg-gray-300 custom:bg-slate-600 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {episodes.map((episode, index) => (
              <div
                key={index}
                onClick={() => onEpisodePlay({ ...episode, index })}
                className="group bg-slate-800/30 dark:bg-slate-800/30 light:bg-white/80 custom:bg-[var(--color-surface)]/30 hover:bg-slate-700/50 dark:hover:bg-slate-700/50 light:hover:bg-gray-50 custom:hover:bg-[var(--color-surface)]/50 backdrop-blur-sm rounded-lg p-4 cursor-pointer transition-all duration-200 border border-slate-700/30 dark:border-slate-700/30 light:border-gray-200 custom:border-slate-600/30 hover:border-purple-500/30 dark:hover:border-purple-500/30 light:hover:border-purple-300 custom:hover:border-[var(--color-primary)]/30"
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-4 h-4 text-white ml-0.5" fill="currentColor" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white dark:text-white light:text-gray-900 custom:text-[var(--color-text)] mb-2 line-clamp-2 group-hover:text-purple-200 dark:group-hover:text-purple-200 light:group-hover:text-purple-600 custom:group-hover:text-[var(--color-primary)] transition-colors">
                      {episode.title}
                    </h3>
                    <p className="text-slate-400 dark:text-slate-400 light:text-gray-600 custom:text-[var(--color-text)]/70 text-sm line-clamp-3 mb-3">
                      {episode.description}
                    </p>
                    
                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-500 light:text-gray-500 custom:text-[var(--color-text)]/60">
                      {episode.pubDate && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(episode.pubDate)}
                        </span>
                      )}
                      {episode.duration && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatDuration(episode.duration)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};